// src/HomePage.js
import React from 'react';
import './Home.css'; // Import your CSS file for styling

function HomePage() {
  return (
    <div className="container mt-5">
      <h3 className ="mt-5"><strong>NAME : SAUARABH SANTOSH PATIL </strong></h3><br></br>
      <h3><strong>PRN : 2020BTECS00031 </strong></h3><br></br>
      <h3><strong>SUBJECT : DATA MINING LAB </strong></h3><br></br>
      <h3><strong>PROJECT : DATA MINING TOOLS IMPLEMENTATION </strong></h3><br></br>



    </div>
  );
}

export default HomePage;
