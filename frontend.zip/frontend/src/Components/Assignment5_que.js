import React from 'react'

const Assignment5_que = () => {
  return (
    <div>Assignment5_que</div>
  )
}

export default Assignment5_que 