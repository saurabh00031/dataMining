from django.contrib import admin
from .models import CSVFile

admin.site.register(CSVFile)